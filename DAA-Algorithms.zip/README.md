# DAA Algorithms (Python)

This repository contains implementations of important algorithms:

## Algorithms Included
- Heap Sort
- Selection Sort
- BFS (Graph Traversal)
- Strassen Matrix Multiplication

## How to Run
python main.py

## Author
Mayur Shinde
